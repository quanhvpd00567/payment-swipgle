<script src="{{ asset('ui/libs/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ asset('ui/libs/bootstrap/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('ui/js/swipgle.min.js') }}"></script>