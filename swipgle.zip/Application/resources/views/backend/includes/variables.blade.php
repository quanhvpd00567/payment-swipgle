<style>
    :root {
        --swipgle-primary-color: {{ $settings->website_main_color }};
        --swipgle-secondary-color: {{ $settings->website_sec_color }};
    }
</style>