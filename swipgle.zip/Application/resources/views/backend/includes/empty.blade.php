<div class="empty">
    <div class="empty-img">
       <img src="{{ asset('images/sections/empty.svg') }}" height="128" alt="empty">
    </div>
    <p class="empty-title">{{__('No data found')}}</p>
    <p class="empty-subtitle text-muted">
       {{__('This section is empty and has no content.')}}
    </p>
 </div>